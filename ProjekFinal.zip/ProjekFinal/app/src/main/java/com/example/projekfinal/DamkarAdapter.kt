package com.example.projekfinal

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class DamkarAdapter internal constructor(private val context: Context) :
    BaseAdapter(){
    internal var Damkar = arrayListOf<damkar>()

    override fun getCount(): Int = Damkar.size

    override fun getItem(i: Int): Any = Damkar[i]

    override fun getItemId(i: Int): Long = i.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val itemView = inflater.inflate(R.layout.row_damkar, parent, false)

        val viewHolder = ViewHolder(itemView as View)

        val fire = getItem(position) as damkar
        viewHolder.bind(fire)
        return itemView
    }

    private val inflater: LayoutInflater =
        context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    private inner class ViewHolder(view: View)
    {
        private val txtNameD: TextView =
            view.findViewById(R.id.nama_damkar)
        private val txtAddressD: TextView =
            view.findViewById(R.id.alamat_damkar)
        private val txtNumberD: TextView =
            view.findViewById(R.id.nomor_damkar)


        fun bind(Damkar: damkar){
            txtNameD.text = Damkar.namefire
            txtAddressD.text = Damkar.addressfire
            txtNumberD.text = Damkar.numberfire
        }
    }
}