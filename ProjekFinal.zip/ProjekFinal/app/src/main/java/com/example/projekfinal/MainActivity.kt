package com.example.projekfinal

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.projekfinal.ui.MainchatActivity


class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val MoveAbout: TextView = findViewById(R.id.about)
        MoveAbout.setOnClickListener(this)

        val DialPolice: ImageButton = findViewById(R.id.callpolice)
        DialPolice.setOnClickListener(this)

        val ListPolice: ImageButton = findViewById(R.id.listpolice)
        ListPolice.setOnClickListener(this)

        val DialFire: ImageButton = findViewById(R.id.callfire)
        DialFire.setOnClickListener(this)

        val ListDamkar: ImageButton = findViewById(R.id.listfire)
        ListDamkar.setOnClickListener(this)

        val DialPsiko: ImageButton = findViewById(R.id.callpsiko)
        DialPsiko.setOnClickListener(this)

        val chatPsiko: ImageButton = findViewById(R.id.chatpsiko)
        chatPsiko.setOnClickListener(this)

        val DialDokter: ImageButton = findViewById(R.id.calldokter)
        DialDokter.setOnClickListener(this)

        val chatDokter: ImageButton = findViewById(R.id.chatdokter)
        chatDokter.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.about -> {
                val moveAbout = Intent(this@MainActivity, aboutActivity::class.java)
                startActivity(moveAbout)
            }

            R.id.callpolice -> {
                val phoneNumber = "110"
                val dialPolice = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                startActivity(dialPolice)
            }

            R.id.listpolice -> {
                val moveListP = Intent(this@MainActivity, listPolisi::class.java)
                startActivity(moveListP)
            }

            R.id.callfire -> {
                val phoneNumber = "113"
                val dialFire = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                startActivity(dialFire)
            }

            R.id.listfire -> {
                val moveListD = Intent(this@MainActivity, listDamkar::class.java)
                startActivity(moveListD)
            }

            R.id.callpsiko -> {
                val phoneNumber = "0217256526"
                val dialPsiko = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                startActivity(dialPsiko)
            }

            R.id.chatpsiko -> {
                val moveChatBot = Intent(this@MainActivity, MainchatActivity::class.java)
                startActivity(moveChatBot)
            }

            R.id.calldokter -> {
                val phoneNumber = "118"
                val dialDokter = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
                startActivity(dialDokter)
            }

            R.id.chatdokter -> {
                val moveChatBot = Intent(this@MainActivity, MainchatActivity::class.java)
                startActivity(moveChatBot)
            }
        }
    }
    fun toastMsg(msg: String?) {
        val toast = Toast.makeText(this, msg, Toast.LENGTH_LONG)
        toast.show()
    }

    fun displayPolice(v: View?) {
        toastMsg("Memanggil Polisi")
    }

    fun displayFire(v: View?) {
        toastMsg("Memanggil Damkar")
    }

    fun displayPsiko(v: View?) {
        toastMsg("Memanggil Darurat Jiwa")
    }

    fun displayDokter(v: View?){
        toastMsg("Memanggil Ambulans")
    }
}