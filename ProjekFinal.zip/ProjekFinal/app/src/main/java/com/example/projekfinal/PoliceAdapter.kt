package com.example.projekfinal

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class PoliceAdapter internal constructor(private val context: Context) :
        BaseAdapter(){
    internal var Polisi = arrayListOf<polisi>()

    override fun getCount(): Int = Polisi.size

    override fun getItem(i: Int): Any = Polisi[i]

    override fun getItemId(i: Int): Long = i.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val itemView = inflater.inflate(R.layout.row_polisi, parent, false)

        val viewHolder = ViewHolder(itemView as View)

        val police = getItem(position) as polisi
        viewHolder.bind(police)
        return itemView
    }

    private val inflater: LayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    private inner class ViewHolder(view: View)
    {
        private val txtNameP: TextView =
                view.findViewById(R.id.nama_polisi)
        private val txtAddressP: TextView =
                view.findViewById(R.id.alamat_polisi)
        private val txtNumberP: TextView =
                view.findViewById(R.id.nomor_polisi)


        fun bind(Polisi: polisi){
            txtNameP.text = Polisi.namepolice
            txtAddressP.text = Polisi.addresspolice
            txtNumberP.text = Polisi.numberpolice
        }
    }
}
