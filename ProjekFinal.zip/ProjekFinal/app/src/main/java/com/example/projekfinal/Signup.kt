package com.example.projekfinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_signup.*

class Signup : AppCompatActivity(), View.OnClickListener {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        auth = FirebaseAuth.getInstance()

        signupbutton.setOnClickListener {
            val email = emailsignup.text.toString().trim()
            val password = passwordsignup.text.toString().trim()

            if (email.isEmpty()) {
                emailsignup.error = "Email tidak boleh kosong!"
                emailsignup.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                emailsignup.error = "Email tidak valid!"
                emailsignup.requestFocus()
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                passwordsignup.error = "Password tidak boleh kosong!"
                passwordsignup.requestFocus()
                return@setOnClickListener
            }

            registerUser(email, password)

        }



        val MoveLogin: TextView = findViewById(R.id.linksignin)
        MoveLogin.setOnClickListener(this)
    }

    private fun registerUser(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email,password)
            .addOnCompleteListener(this){
                if(it.isSuccessful){
                    Toast.makeText(this, "Succesfully Sign Up!", Toast.LENGTH_SHORT).show()
                    Intent(this@Signup, login::class.java).also {
                        it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(it)
                    }
                }

                else{
                    Toast.makeText(this, it.exception?.message, Toast.LENGTH_SHORT).show()
                }
            }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.linksignin -> {
                val moveLogin = Intent(this@Signup, login::class.java)
                startActivity(moveLogin)
            }
        }
    }
}
