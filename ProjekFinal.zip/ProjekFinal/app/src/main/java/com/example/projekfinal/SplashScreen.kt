package com.example.projekfinal

import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        val textView = findViewById<TextView>(R.id.faceapp)
        val shader = LinearGradient(0f, 0f, 0f, textView.textSize, Color.RED, Color.YELLOW, Shader.TileMode.CLAMP)
        textView.paint.shader = shader

        val background: Thread = object : Thread() {
            override fun run() {
                try {

                    sleep((5 * 1000).toLong())

                    val i = Intent(baseContext, login::class.java)
                    startActivity(i)

                    finish()
                } catch (e: Exception) {
                }
            }
        }
        background.start()
    }
}