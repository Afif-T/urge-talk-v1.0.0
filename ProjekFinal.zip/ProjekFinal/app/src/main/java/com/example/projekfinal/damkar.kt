package com.example.projekfinal

data class damkar (
    var namefire : String = "",
    var addressfire : String = "",
    var numberfire : String = ""
)