package com.example.projekfinal

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class data (val uid: String, val email: String,val password: String):
    Parcelable {
    constructor() : this("","","")
}