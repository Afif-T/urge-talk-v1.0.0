package com.example.projekfinal

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class detailDamkar : AppCompatActivity() {companion object {
    const val damkar_name = "nama"
    const val damkar_address= "alamat"
    const val damkar_nomor = "nomor"

    fun newIntent(context: Context, damkarlist: damkar): Intent {
        val detailIntent = Intent(context, detailDamkar::class.java)

        detailIntent.putExtra(damkar_name, damkarlist.namefire)
        detailIntent.putExtra(damkar_address, damkarlist.addressfire)
        detailIntent.putExtra(damkar_nomor, damkarlist.numberfire)

        return detailIntent
    }

}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_damkar)

        val damkarname = findViewById<TextView>(R.id.nama_damkar)
        val damkaraddress = findViewById<TextView>(R.id.alamat_damkar)
        val damkarnumber = findViewById<TextView>(R.id.nomor_damkar)

        val damkarnames = intent.extras?.getString(damkar_name)
        val damkaraddresses = intent.extras?.getString(damkar_address)
        val damkarnumbers = intent.extras?.getString(damkar_nomor)


        damkarname.text = damkarnames.toString()
        damkaraddress.text = damkaraddresses.toString()
        damkarnumber.text = damkarnumbers.toString()

    }
}