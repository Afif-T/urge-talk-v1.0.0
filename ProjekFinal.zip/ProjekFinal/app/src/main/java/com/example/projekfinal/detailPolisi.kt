package com.example.projekfinal

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class detailPolisi : AppCompatActivity() {companion object {
    const val polisi_name = "nama"
    const val polisi_address= "alamat"
    const val polisi_nomor = "nomor"

    fun newIntent(context: Context, polisilist: polisi): Intent {
        val detailIntent = Intent(context, detailPolisi::class.java)

        detailIntent.putExtra(polisi_name, polisilist.namepolice)
        detailIntent.putExtra(polisi_address, polisilist.addresspolice)
        detailIntent.putExtra(polisi_nomor, polisilist.numberpolice)

        return detailIntent
    }

}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_polisi)

        val polisiname = findViewById<TextView>(R.id.nama_polisi)
        val polisiaddress = findViewById<TextView>(R.id.alamat_polisi)
        val polisinumber = findViewById<TextView>(R.id.nomor_polisi)

        val polisinames = intent.extras?.getString(polisi_name)
        val polisiaddresses = intent.extras?.getString(polisi_address)
        val polisinumbers = intent.extras?.getString(polisi_nomor)


        polisiname.text = polisinames.toString()
        polisiaddress.text = polisiaddresses.toString()
        polisinumber.text = polisinumbers.toString()

    }
}