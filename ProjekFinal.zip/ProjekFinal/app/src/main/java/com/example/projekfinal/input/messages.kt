package com.example.projekfinal.input

data class messages (val Message: String, val id: String, val time: String) {
}