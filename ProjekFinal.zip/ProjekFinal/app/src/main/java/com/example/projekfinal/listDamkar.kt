package com.example.projekfinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class listDamkar : AppCompatActivity() {

    private lateinit var adapter: DamkarAdapter
    private lateinit var dataNameD: Array<String>
    private lateinit var dataAddressD: Array<String>
    private lateinit var dataNumberD: Array<String>
    private var fire = arrayListOf<damkar>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_damkar)

        val ListDamkar: ListView = findViewById(R.id.listdamkar)
        adapter = DamkarAdapter(this)
        ListDamkar.adapter = adapter

        prepare()
        addItem()

        ListDamkar.setOnItemClickListener { _, _, position, _ ->
            val selectedDamkars = fire[position]
            val detailDamkar = detailDamkar.newIntent(this, selectedDamkars)
            startActivity(detailDamkar)
        }


    }

    private fun prepare() {
        dataNameD = resources.getStringArray(R.array.data_name_damkar)
        dataAddressD = resources.getStringArray(R.array.data_address_damkar)
        dataNumberD = resources.getStringArray(R.array.data_phone_damkar)
    }

    private fun addItem() {
        for (position in dataNameD.indices) {
            val fires = damkar(
                    dataNameD[position],
                    dataAddressD[position],
                    dataNumberD[position]
            )
            fire.add(fires)
        }
        adapter.Damkar = fire
    }
}