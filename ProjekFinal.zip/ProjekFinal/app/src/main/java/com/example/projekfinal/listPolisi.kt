package com.example.projekfinal


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class listPolisi : AppCompatActivity() {

    private lateinit var adapter: PoliceAdapter
    private lateinit var dataNameP: Array<String>
    private lateinit var dataAddressP: Array<String>
    private lateinit var dataNumberP: Array<String>
    private var police = arrayListOf<polisi>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_polisi)

        val ListPolisi: ListView = findViewById(R.id.listpolisi)
        adapter = PoliceAdapter(this)
        ListPolisi.adapter = adapter

        prepare()
        addItem()

        ListPolisi.setOnItemClickListener { _, _, position, _ ->
            val selectedItems = police[position]
            val detailIntent = detailPolisi.newIntent(this, selectedItems)
            startActivity(detailIntent)
        }


    }

    private fun prepare() {
        dataNameP = resources.getStringArray(R.array.data_name_polisi)
        dataAddressP = resources.getStringArray(R.array.data_address_polisi)
        dataNumberP = resources.getStringArray(R.array.data_phone_polisi)
    }

    private fun addItem() {
        for (position in dataNameP.indices) {
            val polices = polisi(
                    dataNameP[position],
                    dataAddressP[position],
                    dataNumberP[position]
            )
            police.add(polices)
        }
        adapter.Polisi = police
    }
}

