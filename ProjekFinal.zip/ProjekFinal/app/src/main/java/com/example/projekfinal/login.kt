package com.example.projekfinal

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_signup.*

class login : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val MoveSignUp: TextView = findViewById(R.id.linksignup)
        MoveSignUp.setOnClickListener(this)


        signinbutton.setOnClickListener {

            val email = email.text.toString()
            val password = password.text.toString()
            if (email.isEmpty()|| password.isEmpty()) {
                Toast.makeText(this, "Please Insert Email and Password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val progressDialog = ProgressDialog(this,
                R.style.Theme_MaterialComponents_Light_Dialog)
            progressDialog.show()
            FirebaseAuth.getInstance().signInWithEmailAndPassword(email,password)
                .addOnCompleteListener{

                    if (!it.isSuccessful){
                        val intent = Intent (this, login::class.java)
                        startActivity(intent)
                        progressDialog.hide()
                        return@addOnCompleteListener
                    }
                    else
                        Toast.makeText(this, "Succesfully Login", Toast.LENGTH_SHORT).show()
                    val intent = Intent (this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK  .or(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    progressDialog.hide()
                    finish()
                }
                .addOnFailureListener{
                    Toast.makeText(this, "Incorrect email / password", Toast.LENGTH_SHORT).show()

                }
        }

    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.linksignup -> {
                val movesignup = Intent(this@login, Signup::class.java)
                startActivity(movesignup)
            }
        }
    }


}