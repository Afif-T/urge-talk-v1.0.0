package com.example.projekfinal

data class polisi (
    var namepolice : String = "",
    var addresspolice : String = "",
    var numberpolice : String = ""
)