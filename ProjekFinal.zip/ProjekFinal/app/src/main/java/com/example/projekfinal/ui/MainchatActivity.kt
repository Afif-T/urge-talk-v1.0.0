package com.example.projekfinal.ui

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.projekfinal.R
import com.example.projekfinal.input.messages
import com.example.projekfinal.utility.botresponse
import com.example.projekfinal.utility.constants.open_search
import com.example.projekfinal.utility.constants.receive_id
import com.example.projekfinal.utility.constants.send_id
import com.example.projekfinal.utility.time
import com.example.projekfinal.utility.time.timeStamp
import kotlinx.android.synthetic.main.activity_chat_main.*
import kotlinx.coroutines.*

class MainchatActivity : AppCompatActivity() {

    var messagesList = mutableListOf<messages>()
    private lateinit var adapter: chatAdapter
    private var botList = listOf("Ewing", "Ewing", "Ewing")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_main)

        recyclerView()

        clickEvents()

        val random = (0..2).random()
        customMessage("Hai semua nama gua ${botList[random]}, dan terima kasih telah memberi gue kesempatan untuk menemani " +
                "malam jumat lo.\n" +
                "\n" +
                "Ketik hai untuk kata kunci berikutnya.")

    }

    private fun clickEvents() {
        btn_send.setOnClickListener {
            sendMessage()
        }

        et_message.setOnClickListener {
            GlobalScope.launch {
                delay(100)

                withContext(Dispatchers.Main) {
                    rv_messages.scrollToPosition(adapter.itemCount - 1)
                }
            }
        }
    }
    private fun recyclerView(){
        adapter = chatAdapter()
        rv_messages.adapter = adapter
        rv_messages.layoutManager = LinearLayoutManager(applicationContext)
    }

    override fun onStart() {
        super.onStart()

        GlobalScope.launch {
            delay(100)
            withContext(Dispatchers.Main) {
                rv_messages.scrollToPosition(adapter.itemCount -1)
            }
        }
    }

    private fun sendMessage(){
        val message = et_message.text.toString()
        val timeStamp = timeStamp()

        if(message.isNotEmpty()){
            et_message.setText("")

            messagesList.add(messages(message, send_id, timeStamp))
            et_message.setText("")

            adapter.InsertMessage(messages(message, send_id, timeStamp))
            rv_messages.scrollToPosition(adapter.itemCount -1)

            botResponse(message)
        }
    }

    private fun botResponse(message: String){
        val timeStamp = timeStamp()

        GlobalScope.launch {
            delay(1000)
            withContext(Dispatchers.Main){
                val response = botresponse.basicResponse(message)

                messagesList.add(messages(response, receive_id, timeStamp))
                adapter.InsertMessage(messages(response, receive_id, timeStamp))
                rv_messages.scrollToPosition(adapter.itemCount -1)

                when(response){
                    open_search -> {
                        val site = Intent(Intent.ACTION_VIEW)
                        val searchTerm: String? = message.substringAfter("search")
                        site.data = Uri.parse("https://www.google.com/search?&q=$searchTerm")
                        startActivity(site)
                    }
                }
            }
        }
    }


    private fun customMessage(message: String){
        GlobalScope.launch {
            delay(1000)
            withContext(Dispatchers.Main){
                val timeStamp = time.timeStamp()
                messagesList.add(messages(message, receive_id, timeStamp))
                adapter.InsertMessage(messages(message, receive_id, timeStamp))

                rv_messages.scrollToPosition(adapter.itemCount -1)
            }
        }
    }
}