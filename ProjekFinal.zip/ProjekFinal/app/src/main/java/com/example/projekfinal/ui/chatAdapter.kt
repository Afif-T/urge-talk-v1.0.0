package com.example.projekfinal.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.projekfinal.R
import com.example.projekfinal.input.messages
import com.example.projekfinal.utility.constants.receive_id
import com.example.projekfinal.utility.constants.send_id
import kotlinx.android.synthetic.main.chat_items.view.*
import android.annotation.SuppressLint

class chatAdapter: RecyclerView.Adapter<chatAdapter.MessageViewHolder>(){

    var chatsList = mutableListOf<messages>()

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        return MessageViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.chat_items, parent,false))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val currentMessage = chatsList[position]

        when (currentMessage.id){
            send_id -> {
                holder.itemView.user_message.apply {
                    text = currentMessage.Message
                    visibility = View.VISIBLE
                }
                holder.itemView.bot_message.visibility = View.GONE
            }

            receive_id -> {
                holder.itemView.bot_message.apply {
                    text = currentMessage.Message
                    visibility = View.VISIBLE
                }
                holder.itemView.user_message.visibility = View.GONE
            }
        }
    }

    override fun getItemCount(): Int {
        return chatsList.size
    }

    fun InsertMessage(Message: messages){
        this.chatsList.add(Message)
        notifyItemInserted(chatsList.size)
    }
}