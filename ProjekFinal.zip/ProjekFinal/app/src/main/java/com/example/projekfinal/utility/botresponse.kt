package com.example.projekfinal.utility

import com.example.projekfinal.utility.constants.open_search

object botresponse {
    fun basicResponse(_message: String):String{

        val random = (0..2).random()
        val message = _message.toLowerCase()

        return when {

            message.contains("hai") -> {
             when (random){
                 0 -> "Hai, ada yang bisa aku bantu? Berikut kata kunci selanjutnya: \n" +
                         "\n" +
                         "1. sehat (buat kamu yang punya keluhan kesehatan)\n" +
                         "2. waras (buat kamu yang punya keluhan kejiwaan)"
                 1 -> "Hi, aku ada cuma buat kamu. Berikut kata kunci selanjutnya: \n" +
                         "\n" +
                         "1. sehat (buat kamu yang punya keluhan kesehatan)\n" +
                         "2. waras (buat kamu yang punya keluhan kejiwaan)"
                 2 -> "Halo kamu! Berikut kata kunci selanjutnya: \n " +
                         "\n" +
                         "1. sehat (buat kamu yang punya keluhan kesehatan)\n" +
                         "2. waras (buat kamu yang punya keluhan kejiwaan)"
                 else -> "Error"
             }
            }

            message.contains("sehat") -> {
                when (random){
                    0 -> "Sepertinya kamu memiliki gangguan dengan kesehatanmu, Berikut adalah " +
                            "pilihan yang mungkin bisa membantumu :\n" +
                            "\n" +
                            "1. demam\n" +
                            "2. sakit kepala\n" +
                            "3. sakit hati"
                    1 -> "Kondisi tubuhmu kurang baik? Berikut pilihan yang mungkin bisa membantumu :\n" +
                            "\n" +
                            "1. demam\n" +
                            "2. sakit kepala\n" +
                            "3. sakit hati"
                    2 -> "Sudah kuduga ada yang salah denganmu. Berikut pilihan yang mungkin bisa" +
                            "membantumu :\n" +
                            "\n" +
                            "1. demam\n" +
                            "2. sakit kepala\n" +
                            "3. sakit hati"
                    else -> "Error"
                }
            }

            message.contains("demam") -> {
                when (random){
                    0 -> "Demam dapat terjadi ketika kamu banyak bekerja namun kurang istirahat. Istirahat " +
                            "dan perbanyak kandungan vitamin dalam tubuhmu. GWS Kamu! :)"
                    1 -> "Demam dapat terjadi ketika kamu banyak bekerja namun kurang istirahat. Istirahat " +
                            "dan perbanyak kandungan vitamin dalam tubuhmu. GWS Kamu! :)"
                    2 -> "Demam dapat terjadi ketika kamu banyak bekerja namun kurang istirahat. Istirahat " +
                            "dan perbanyak kandungan vitamin dalam tubuhmu. GWS Kamu! :)"
                    else -> "Error"
                }
            }

            message.contains("sakit kepala") -> {
                when (random){
                    0 -> "Sakit kepala bisa jadi salah satu gejala masuk angin. Ketika kamu masuk angin " +
                            "sebaiknya perbanyak makan, istirahat, serta oleskan minyak hangat. GWS Kamu! :)"
                    1 -> "Sakit kepala bisa jadi salah satu gejala masuk angin. Ketika kamu masuk angin " +
                            "sebaiknya perbanyak makan, istirahat, serta oleskan minyak hangat. GWS Kamu! :)"
                    2 -> "Sakit kepala bisa jadi salah satu gejala masuk angin. Ketika kamu masuk angin " +
                            "sebaiknya perbanyak makan, istirahat, serta oleskan minyak hangat. GWS Kamu! :)"
                    else -> "Error"
                }
            }

            message.contains("sakit hati") -> {
                when (random){
                    0 -> "monmaap salah lapak bosq ni bukan tinder"
                    1 -> "makanya udahan si ngestalknya. percuma dia nengok ke lu aja ogah saprudin"
                    2 -> "besok-besok pacaran sama udang aja ngab"
                    else -> "Error"
                }
            }

            message.contains("waras") -> {
                when (random){
                    0 -> "Kamu merasa ga layak? Putus asa? Sedih berkepanjangan? Kira-kira apa yang paling " +
                            "menggambarkan dirimu :\n" +
                            "\n" +
                            "1. depresi\n" +
                            "2. sedih berkepanjangan\n" +
                            "3. biasa aja"
                    1 -> "Kamu merasa terbuang? Insecure berkepanjangan? Kira-kira apa yang paling " +
                            "menggambarkan dirimu :\n" +
                            "\n" +
                            "1. depresi\n" +
                            "2. sedih berkepanjangan\n" +
                            "3. biasa aja"
                    2 -> "Kamu sedih ditinggal dia? Sedih diremehkan orang tua? Kira-kira apa yang paling " +
                            "menggambarkan dirimu :\n" +
                            "\n" +
                            "1. depresi\n" +
                            "2. sedih berkepanjangan\n" +
                            "3. biasa aja"
                    else -> "Error"
                }
            }

            message.contains("depresi") -> {
                when (random){
                    0 -> "Depresi adalah penyakit mental yang tidak bisa dibiarkan lama. Semakin kamu " +
                            "membiarkannya dapat terjadi hal-hal yang tidak diinginkan. Segera " +
                            "hubungi konselor terpercaya. Semangat kamu! :)"
                    1 -> "Depresi adalah penyakit mental yang tidak bisa dibiarkan lama. Semakin kamu " +
                            "membiarkannya dapat terjadi hal-hal yang tidak diinginkan. Segera " +
                            "hubungi konselor terpercaya. Semangat kamu! :)"
                    2 -> "Depresi adalah penyakit mental yang tidak bisa dibiarkan lama. Semakin kamu " +
                            "membiarkannya dapat terjadi hal-hal yang tidak diinginkan. Segera " +
                            "hubungi konselor terpercaya. Semangat kamu! :)"
                    else -> "Error"
                }
            }

            message.contains("sedih berkepanjangan") -> {
                when (random){
                    0 -> "Sedih dapat terjadi karena berbagai alasan salah satunya ditinggal orang " +
                            "terkasih. Perbanyak olahraga dan aktivitas agar kamu teralihkan dari " +
                            "sedihmu. Kamu berhak bahagia! :)"
                    1 -> "Sedih dapat terjadi karena berbagai alasan salah satunya ditinggal orang " +
                            "terkasih. Perbanyak olahraga dan aktivitas agar kamu teralihkan dari " +
                            "sedihmu. Kamu berhak bahagia! :)"
                    2 -> "Sedih dapat terjadi karena berbagai alasan salah satunya ditinggal orang " +
                            "terkasih. Perbanyak olahraga dan aktivitas agar kamu teralihkan dari " +
                            "sedihmu. Kamu berhak bahagia! :)"
                    else -> "Error"
                }
            }

            message.contains("biasa aja") -> {
                when (random){
                    0 -> "ye ngapain chat gua. jomblo si kesian bat"
                    1 -> "ngapain masih disini coba"
                    2 -> "ngobrol aja apa kali yak kita"
                    else -> "Error"
                }
            }

            message.contains("search") -> {
                open_search
            }

            else -> {
                when (random){
                    0 -> "Ga ngerti. coba ketik sesuai kata kuncinya dong"
                    1 -> "Huruf kapital perhatiin"
                    2 -> "Jangan semaunya sendiri. sesuai kata kunci panjul."
                    else -> "Error"
                }
            }

        }
    }

}