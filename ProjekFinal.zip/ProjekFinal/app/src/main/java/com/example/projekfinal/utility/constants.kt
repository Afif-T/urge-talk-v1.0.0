package com.example.projekfinal.utility

object constants {

    const val send_id = "Send_ID"
    const val receive_id = "Receive_ID"

    const val open_google = "opening Google"
    const val open_search = "Searching"
}