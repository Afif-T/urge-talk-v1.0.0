package com.example.projekfinal.utility

import java.sql.Date
import java.sql.Timestamp
import java.text.SimpleDateFormat

object time {

    fun timeStamp(): String{
        val timeStamps = Timestamp(System.currentTimeMillis())
        val sdf = SimpleDateFormat("HH:mm")
        val time = sdf.format(Date(timeStamps.time))

        return time.toString()
    }

}